import { Component } from '@angular/core';

@Component({
  selector: 'app-fahrenheit',
  standalone: true,
  imports: [],
  templateUrl: './fahrenheit.component.html',
  styleUrl: './fahrenheit.component.css'
})
export class FahrenheitComponent {

}
