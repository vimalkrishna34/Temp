import { Component } from '@angular/core';

@Component({
  selector: 'app-celsius',
  standalone: true,
  imports: [],
  templateUrl: './celsius.component.html',
  styleUrl: './celsius.component.css'
})
export class CelsiusComponent {

}
